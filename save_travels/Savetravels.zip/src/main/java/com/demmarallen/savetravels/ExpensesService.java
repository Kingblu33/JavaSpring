package com.demmarallen.savetravels;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.demmarallen.savetravels.model.Expenses;
import com.demmarallen.savetravels.repository.ExpensesRepository;

@Service
public class ExpensesService {
	private final ExpensesRepository expensesReposityory;

	public ExpensesService(ExpensesRepository expensesReposityory) {
		this.expensesReposityory = expensesReposityory;
	}

	public ArrayList<Expenses> findAll() {
		return (ArrayList<Expenses>) 		expensesReposityory.findAll();
	}

	public Optional<Expenses> editbyid(Long id) {
		return expensesReposityory.findById(id);
	}

	public void deleteById(Long id) {
		expensesReposityory.deleteById(id);
	}
 
	public Expenses newExpense(Expenses e) {
        return expensesReposityory.save(e);
    }
}
